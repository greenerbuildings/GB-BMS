////////////////////////////////////////////////////////////
// file: SOCKETSETTERGETTER.js 
// ver: Sep 14 2012, 13:30
////////////////////////////////////////////////////////////

var USER_ID = " 16 "; //user id is important when sending commands: ensure there are spaces for the delimiter
var DEBUG_MODE = true;
var  CATEGORY_CMD = "CMD";
var  CATEGORY_SET = "SET";
var  LIGHT_DIM_CTRL = "03";
var  LIGHT_SWITCH_ON = "06";
var  LIGHT_SWITCH_OFF = "07";
var  BLINDS_ROTATE_LEVEL_CTRL = "28";
var  BLINDS_HEIGHT_CTRL = "33";
var  ILDC_CTRL_START = "34";
var  ILDC_CTRL_STOP = "35";
var myWebSocket;
var freezeMode = false; //used to toggle the background - emululate freezing settings
var artificialLightInside=0;
wsURI = ""; //may include port number
openStatus = false;
//sensors = null;
var artificialLightInside; //value of lamps out of 255 (change max in slider options). NOTE, NO LONGER LUX!
var indoorTotalLightVal; //total light inside from daylight and lamps - represents new set-point if adjusted by user
var dayLightOutside; //total available light outside
var dayLightInside; //lux of light inside from daylight only
var lightSensorCallback; //callback function when light sensor heartbeat is triggered
var pollInterval; //polling interval for light sensor heartbeat
var glareDetected; //flag to indicate if glare sensor is triggered
var blockIncomingEvents;
var openStatus;	
var myDeviceManager; //instance of SocketSetterGetter for use in main program
var oldGlare = 5000; //used to check if the glare value has changed
var retryCount = 0;
var RETRY_NOTIFY_MAX = 2;
var MAX_CUTOFF = 70;
var lastTimeReceived = -1012030;

function SocketSetterGetter(artificial_LightInside, indoorTotal_LightVal, dayLight_Outside, lightSensor_Callback, poll_Interval)
{
	artificialLightInside = artificial_LightInside; //value of lamps out of 255 (change max in slider options). NOTE, NO LONGER LUX!
	indoorTotalLightVal = indoorTotal_LightVal; //total light inside from daylight and lamps - represents new set-point if adjusted by user
	dayLightOutside = dayLight_Outside; //total available light outside
	dayLightInside = indoorTotalLightVal - artificialLightInside; //lux of light inside from daylight only
	lightSensorCallback = lightSensor_Callback; //callback function when light sensor heartbeat is triggered
	pollInterval = poll_Interval; //polling interval for light sensor heartbeat
	glareDetected = false; //flag to indicat if glare sensor is triggered
	blockIncomingEvents = false;
	openStatus = false;	
}


function reconnectToServer(uri)
{
	myDeviceManager.connect(uri);
}

 $(document).ready(function(){ //process the widgets when the document is loaded

////////////////SOCKETS/////////////////////////////////////////////
SocketSetterGetter.prototype.connect = function(uri) {
	wsURI = uri;
	
	if (!window.WebSocket) {
		window.WebSocket = window.MozWebSocket;
	}
	
	//var wsImpl = window.WebSocket || window.MozWebSocket;
	
	console.log("Setter web socket connecting to " + wsURI);
	//window.ws = new wsImpl('ws://localhost:8181/consoleappsample', 'my-protocol');
	// create a new websocket and connect	
	
	 if (window.WebSocket) {
		myWebSocket = new WebSocket(wsURI);
	 }
	
	//myWebSocket = new wsImpl(wsURI, 'my-protocol');
	
	myWebSocket.onopen = function () {
		console.log(".. connection open");
		$("#connectStatus").css("visibility","hidden");
		retryCount = 0;
		openStatus = true;
		//do nothing
	};

	myWebSocket.onclose = function () {
		console.log('.. connection to web socket closed, re-establishing connection......');
		openStatus = false;
		retryCount = retryCount + 1;
		if(retryCount > RETRY_NOTIFY_MAX)
		{
			//sendMail();
		}
		$("#connectStatus").css("visibility","visible");
		setTimeout(function(){reconnectToServer(wsURI)}, 5000);
	};
	
	myWebSocket.onmessage = function (evt) {
		
		//var timeNow = new Date().getTime();
		//if(timeNow - timeLastReceivedEvent > 60000)
		//	location.reload()
		//timeLastReceivedEvent = timeNow;
		
		var messageString = evt.data;
		
		if(DEBUG_MODE) console.log("raw message = " + messageString);
		
		var messageArray = messageString.split(" ");
		var user = parseInt(messageArray[1]);
		var room = parseInt(messageArray[3]);
		var dimLevel = parseInt(messageArray[5]);
		var lux = parseInt(messageArray[7]);
		var setpoint = parseInt(messageArray[9]);
		var blindsHeight = parseInt(messageArray[11]);
		var blindsAngle = parseInt(messageArray[13]);
		var cutoffAngle = parseInt(messageArray[15]);
		var glare = parseInt(messageArray[17]);
		var modeString = messageArray[19];
		var mode = false;
	

		if(blockIncomingEvents) return; //don't handle incoming messages from server until UI command is processsed
	
		if(modeString == "Integrated") mode =  false; //here mode => freeze mode state on server
		else if(modeString == "Manual") mode = true;

		//if(DEBUG_MODE) console.log("manual mode = " + mode);

		
		//check if values have changed
		if(artificialLightInside != dimLevel)
		{
			if(DEBUG_MODE) console.log("incoming message for lights: " + messageString);
			artificialLightInside = dimLevel;
			$( "#lightSlider" ).slider("value", artificialLightInside);
			var visStatus = (artificialLightInside <= 25) ? "visible" : "hidden";
			if($("#leaf").css("visibility") != visStatus)
				$("#leaf").css("visibility",visStatus);			
		}
		
		if(Math.abs(myBlindsWidget.blindsPos - (blindsHeight * 100 / 255)) > 3)
		{
			if(DEBUG_MODE) console.log("incoming message for height: " + messageString);
			myBlindsWidget.blindsPos = blindsHeight * 100 / 255;
			myBlindsWidget.updateBlinds();
		}

		if((90 - myBlindsWidget.blindsAngle) != blindsAngle)
		{
			
			myBlindsWidget.blindsAngle = 90 - blindsAngle;
			myBlindsWidget.updateBlinds();
			if(DEBUG_MODE) console.log("incoming message for angle: " + myBlindsWidget.blindsAngle + ":" + blindsAngle);
		}
		
				
		
		if(oldGlare != glare)
		{
			 if(DEBUG_MODE) console.log("incoming message for glare: " + myBlindsWidget.glareDetected + ":" + glare + "," + oldGlare + ":" + glare);
			 if(glare < 0) 
			 {
				myBlindsWidget.glareDetected = true;
				myBlindsWidget.glareStartAngle = Math.min(-(90 - cutoffAngle), -(90 - MAX_CUTOFF)); //70 degrees is the maximum cutoff angle
				myBlindsWidget.glareEndAngle = Math.max((90 - cutoffAngle), (90 - MAX_CUTOFF)); //70 degrees is the maximum cutoff angle
				//can also call myBlindsWidget.setGlareAngle()
				oldGlare = glare;
			}
			else
			{
				myBlindsWidget.glareDetected = false;
				oldGlare = glare
			}
			
			myBlindsWidget.updateBlinds();
		}
		
				if(freezeMode != mode)
		{
			
			elem=document.getElementById("tlm-frame"); //toggle the color of the background div containing the widgets
			if(freezeMode)
			{
				if(DEBUG_MODE) console.log("incoming message for automode mode: " + messageString);
				 //myDeviceManager.setAutoMode(true);
				 elem.style.backgroundColor = '#FFFFFF';
				 $('#freeze').css('background-image', "url(images/freeze.png)"); //set css sprite
				 freezeMode = false;

			}
			else {
				 //myDeviceManager.setAutoMode(false);
				 if(DEBUG_MODE) console.log("incoming message for manual mode: " + messageString);
				 elem.style.backgroundColor = '#DDDDDD';
				 $('#freeze').css('background-image', "url(images/unfreeze.png)"); //set css sprite
				 freezeMode = true;
			}
			//blockEvents(3000);
			return;
		}
		
	};
	
}

});

SocketSetterGetter.prototype.setBlinds = function(height, angle)
{
	this.setBlindsHeight(height);
	this.setBlindsAngle(angle);
}

SocketSetterGetter.prototype.setBlindsHeight = function(height)
{
	//height should be a value between 0 and 255
	this.sendMessage(BLINDS_HEIGHT_CTRL,height * 255 / 100);
}

SocketSetterGetter.prototype.setBlindsAngle = function(angle)
{
	//angle between 0 and 180 degrees (clock-wise)?
	this.sendMessage(BLINDS_ROTATE_LEVEL_CTRL, (90 - angle));
}

SocketSetterGetter.prototype.setLightLevel = function(level)
{
	var adjustedLevel = (level > 8)?level:0;
	this.sendMessage(LIGHT_DIM_CTRL, adjustedLevel);
}

SocketSetterGetter.prototype.setAutoMode = function(mode)
{
	if(mode)
	{
		this.sendMessage(ILDC_CTRL_START, "11");
	}
	else
	{
		this.sendMessage(ILDC_CTRL_STOP, "11");
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////
// PLACEHOLDER METHOD FOR DYNALITE CONTROL METHODS
////////////////////////////////////////////////////////////////////////////////////////////////////

SocketSetterGetter.prototype.sendMessage = function (code, value)
{	
	
	if (myWebSocket.readyState == 1) {	
			console.log("sending command " + code + " with value " + Math.round(value) + " to zone" + ZONE_ID);
			myWebSocket.send(CATEGORY_CMD + " " + code + ZONE_ID + Math.round(value));	
	}
	else
		console.log("cannot send command " + code + " with value " + Math.round(value) + "to zone" + ZONE_ID);
}