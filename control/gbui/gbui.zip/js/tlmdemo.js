////////////////////////////////////////////////////////////////////////////////////////////////////
// File: tlmdemo.js
// Ver:  Sep 14 2012, 15:00
// Desc:
//  Main UI code to initialize the TLM UI and handle UI events and light levels.
//	Note that min/max set-points are currently not implemented in the UI. The min-setpoint is 
//	derived from the indoorTotalLightVal sensor and is recalculated when the external light level 
//	is lower than the internal light level after the user modifies the artificial lights. 
//	The max lighting set-point is recalculated from indoorTotalLightVal when the user modifies  
// 	the blinds when the external lighting level is high.
////////////////////////////////////////////////////////////////////////////////////////////////////

//TODO:
/*
For Comfort, allow for continuous range of -2 to +2
For Temp allow for continuous range of 16 to 27
Add toggle button to switch between temperature mode and comfort mode
Show a line of current temperature / comfort (depending on mode) to show the difference between current temp and desired temp

*/

function LightSlider(id, dimLevel, stepSize, maxLevel, lightLevel)
{
	this.id = id;
	this.dimLevel = dimLevel;
	this.stepSize = stepSize;
	this.maxLevel = maxLevel;
	this.lightLevel = lightLevel;
	console.log(this.id);
}


LightSlider.prototype.updateSlider = function()
{
}


function logEvent(event) {
  console.log(event.type);
}
window.applicationCache.addEventListener('checking', logEvent, false);
window.applicationCache.addEventListener('noupdate', logEvent, false);
window.applicationCache.addEventListener('downloading', logEvent, false);
window.applicationCache.addEventListener('cached', logEvent, false);
window.applicationCache.addEventListener('updateready', logEvent, false);
window.applicationCache.addEventListener('obsolete', logEvent, false);
window.applicationCache.addEventListener('error', logEvent, false);


////////////////////////////////////////////////////////////////////////////////////////////////////
// DECLARE VARS, FUNCTIONS AND INITIALIZE 
// Note: some initializations are made within the slider widget declarations
////////////////////////////////////////////////////////////////////////////////////////////////////
//BEWARE - some initializations are made within the slider widget declarations//
var SERVER_ADDRESS = 'ws://localhost:8282/websocket/'; //wsURI location for setting system state values
//var SERVER_ADDRESS = 'ws://130.144.79.149:8181/consoleappsample'; //wsURI location for setting system state values
var ZONE_ID = " 16 "//used to identify a user or area for which the UI commands should apply on the server

var maxLight = 3000; //max possible lux limited by slider - also set as max in slider widget options
var minLight = 200; //min lux level in auto mode
var freezeMode = false; //used to toggle the background - emululate freezing settings
var SENSOR_POLLING_INTERVAL = 1000;
var blinds1;

var skyBlue = "#009FE3";
var glareOrange = "#E94E1B";
var lightYellow = "F4ED00";
var blockIncomingEvents = false; //whenever the blinds and lights are changed by the user, this flag will prevent listening to updates from the server until the change has been honoured
var blockingTimer = null; //track if the blocking timer is still running
var freezeToggle; // global declaration of toggle method so that other contexts can access it
var lastLightUpdate = -1000; //used to reduce the number of events sent to the server

	var unblockEvents = function ()
	{
		console.log("unblocking events");
		blockIncomingEvents = false;	
		lastLightUpdate = -1;
	}

	var blockEvents = function(timeout)
	{
		blockIncomingEvents = true;	
		console.log("blocking events " + blockingTimer);
		if(blockingTimer != null)
			clearTimeout(blockingTimer);
		blockingTimer = setTimeout(unblockEvents, timeout);
	}

 
 $(document).ready(function(){ //process the widgets when the document is loaded
    $( "#tabs" ).tabs();
	 
	lightSliders = new Array();
	//(sliderElement, dimLevel, stepSize, maxLevel, lightLevel)
	lightSliders[0] = new LightSlider("lightSlider1", 500, 10, 1000, 0);
	lightSliders[1] = new LightSlider("lightSlider2", 500, 10, 1000, 0);
	lightSliders[2] = new LightSlider("lightSlider3", 500, 10, 1000, 0);
	lightSliders[3] = new LightSlider("lightSlider4", 500, 10, 1000, 0);
	document.body.addEventListener('touchmove', function(e){ e.preventDefault(); }); //only applies to touch screens to disable scrolling within a web page
	//the lights and blinds controller is used to emulate control functions of the artificial lights and blinds motors
	myDeviceManager = new SocketSetterGetter(50, 300, 1200, sensorUpdateEvent, SENSOR_POLLING_INTERVAL); //passes uri of controller for web socket messaging
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// Timer callback which ignores incoming state events until the control event is properly handled by the server
	////////////////////////////////////////////////////////////////////////////////////////////////////	


	////////////////////////////////////////////////////////////////////////////////////////////////////
	// BLINDS WIDGET CONTROL EVENT HANDLING
	// 
	////////////////////////////////////////////////////////////////////////////////////////////////////	
	var blindsControlEvent = function (id, val)
	{
		console.log("control event from " + id + " with val " + val)
	
		if(freezeMode) 
			freezeToggle();		
		redrawSliders(); //update the new readings from the sensors
		updateLeaf(); //update the energy efficiency feedback
		//TODO: change scalefactor for algorithm according to light level set by new blinds position and angle
		var blindWidget;
		if(id == 1) blindWidget = blinds1;
		else if(id == 2) blindWidget = blinds2;
		else blindWidget = blinds3;
		
		if(val == HEIGHT_CHANGED)
			myDeviceManager.setBlindsHeight(blindWidget.blindsPos);
				
		if(val == ANGLE_CHANGED)
			myDeviceManager.setBlindsAngle(blindWidget.blindsAngle);
		blockEvents(15000);
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// SENSOR EVENT HANDLING - dummy callback currently invoked by a timer
	////////////////////////////////////////////////////////////////////////////////////////////////////		
	var sensorUpdateEvent = function ()
	{	
		if(typeof sensorUpdateEvent.prevPos == 'undefined') {
			sensorUpdateEvent.prevPos = blinds1.blindsPos; //create a static variable to check for changes in blinds
			sensorUpdateEvent.prevAng = blinds1.blindsAngle; //create a static variable to check for changes in blinds		
			sensorUpdateEvent.prevGlareDetected = glareDetected;
		}

		glareDetected = Math.random() > 0.7? true:false;
		
		if(glareDetected != sensorUpdateEvent.prevGlareDetected)
		{
			if(glareDetected)
				$('#angleSlider').css('background', "transparent url(images/glare-slider-bg.png) no-repeat top left"); //set css sprite
			 else
				$('#angleSlider').css('background', "transparent url(images/slider-bg.png) no-repeat top left"); //set css sprite
			 sensorUpdateEvent.prevGlareDetected = glareDetected;
		}

		//hack to calculate the light penetrating through the blinds (should be read out from interior light sensor)
		var heightLightFactor = (100 - blinds1.blindsPos) * 0.01 ; 
		var angLightFactor =  ((85.0 - Math.abs(blinds1.blindsAngle))/85.0);
		
		if(heightLightFactor < 0.09) heightLightFactor = 0.0;
		if(heightLightFactor > 0.91) heightLightFactor = 1.0;
		if(Math.abs(angLightFactor) > 0.95) heightLightFactor = 1.0;
		
		lightFromAngle = dayLightOutside * angLightFactor;
		lightFromHeight = heightLightFactor * dayLightOutside;
		dayLightInside = Math.min(dayLightOutside , lightFromAngle + lightFromHeight);
		
		//indoorTotalLightVal = Math.min(maxLight, artificialLightInside + dayLightInside);
		
		if((sensorUpdateEvent.prevPos != blinds1.blindsPos) || (sensorUpdateEvent.prevAng != blinds.blindsAngle))
		{
			sensorUpdateEvent.prevPos = blinds1.blindsPos; //create a static variable to check for changes in blinds
			sensorUpdateEvent.prevAng = blinds1.blindsAngle; //create a static variable to check for changes in blinds
			redrawSliders();
		}
	}
	

	////////////////////////////////////////////////////////////////////////////////////////////////////
	// UPDATE THE UI - invoked when the user changes the artificial lights
	////////////////////////////////////////////////////////////////////////////////////////////////////
	var lightControlEvent = function (id)
	{
		console.log("light slider id = " + id)
		if(freezeMode) 
			freezeToggle();
		
		
		
		if(artificialLightInside != $( "#lightSlider1" ).slider( "value" ))	
		{
			artificialLightInside = $( "#lightSlider1" ).slider( "value" );
			//indoorTotalLightVal = dayLightInside + artificialLightInside;
			
			if(Math.abs(lastLightUpdate - artificialLightInside) > 10 || artificialLightInside > 249 || artificialLightInside < 6)
			{
				myDeviceManager.setLightLevel(artificialLightInside); //call lighting controller (via web socket) 
				//console.log ("debug slider " + artificialLightInside);
				lastLightUpdate = artificialLightInside;
				blockEvents(3000);
				
			}
			updateLeaf();
		}
	}

	var tempControlEvent = function ()
	{
	/*
		if(freezeMode) 
			freezeToggle();
		if(artificialLightInside != $( "#lightSlider" ).slider( "value" ))	
		{
			artificialLightInside = $( "#lightSlider" ).slider( "value" );
			//indoorTotalLightVal = dayLightInside + artificialLightInside;
			
			if(Math.abs(lastLightUpdate - artificialLightInside) > 10 || artificialLightInside > 249 || artificialLightInside < 6)
			{
				myDeviceManager.setLightLevel(artificialLightInside); //call lighting controller (via web socket) 
				console.log ("debug slider " + artificialLightInside);
				lastLightUpdate = artificialLightInside;
				blockEvents(3000);
				
			}


			updateLeaf();
		}
		*/
	}

	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// BLINDS WIDGET INITIALIZATION
	////////////////////////////////////////////////////////////////////////////////////////////////////		
	blindsCanvas1=document.getElementById("blindsCanvas1");
	blinds1 = new BlindsWidget(1,16,100,blindsCanvas1, blindsCanvas1.getContext("2d"),0,50, blindsControlEvent);
	blindsCanvas2=document.getElementById("blindsCanvas2");
	blinds2 = new BlindsWidget(2,16,100,blindsCanvas2, blindsCanvas2.getContext("2d"),0,50, blindsControlEvent);
	blindsCanvas3=document.getElementById("blindsCanvas3");
	blinds3 = new BlindsWidget(3,16,100,blindsCanvas3, blindsCanvas3.getContext("2d"),0,50, blindsControlEvent);
	
	/*
	blinds1.blindsCanvas.addEventListener('mousemove', $.proxy( blinds1.ev_mousemove,blinds1), false);    
	blinds1.blindsCanvas.addEventListener('mousedown', $.proxy( blinds1.ev_mousedown,blinds1), false);    
	blinds1.blindsCanvas.addEventListener('mouseup', $.proxy( blinds1.ev_mouseup,blinds1), false);    
	blinds1.blindsCanvas.addEventListener('touchstart', $.proxy( blinds1.ev_mousedown,blinds1), false);    
	blinds1.blindsCanvas.addEventListener('touchmove',$.proxy( blinds1.ev_mousemove,blinds1), true);    
	blinds1.blindsCanvas.addEventListener('touchend', $.proxy( blinds1.ev_mouseup,blinds1), false);	
	*/
	//myDeviceManager = new SocketGetter(300, 300, 1200, sensorUpdateEvent, SENSOR_POLLING_INTERVAL); 
	
	//need to instantiate this object after the callback declaration, but before the widgets are updated...		
	
	//init(myDeviceManager);
	myDeviceManager.connect(SERVER_ADDRESS);
	blinds1.updateBlinds();
	blinds2.updateBlinds();
	blinds3.updateBlinds();
	updateLeaf();	    

	////////////////////////////////////////////////////////////////////////////////////////////////////
	// FREEZE MODE HANDLERS
	////////////////////////////////////////////////////////////////////////////////////////////////////		
	$("#freeze").click(function() {
		freezeToggle();
	});

	freezeToggle = function ()
	{
		elem=document.getElementById("tlm-frame"); //toggle the color of the background div containing the widgets
		if(freezeMode)
		{
			 myDeviceManager.setAutoMode(true);
			 elem.style.backgroundColor = '#FFFFFF';
					 $('#freeze').css('background-image', "url(images/freeze.png)"); //set css sprite

		}
		else {
			 myDeviceManager.setAutoMode(false);
			 elem.style.backgroundColor = '#DDDDDD';
			 $('#freeze').css('background-image', "url(images/unfreeze.png)"); //set css sprite
		}
		freezeMode = !freezeMode;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	// JQUERY SLIDER WIDGET INITIALIZATION
	////////////////////////////////////////////////////////////////////////////////////////////////////
	
    $(function() {
		for(var i = 0; i < 4; i++)
		{	
			//(sliderElement, dimLevel, stepSize, maxLevel, lightLevel)
			$( "#lightSlider" + (i+1) ).slider({ //#lightSlider refers to slider for controlling artificial lighting
				orientation: "vertical",
				range: "min",
				min: 0,
				max: lightSliders[i].maxLevel, //note 1000 lux represents the total available from the artificial lighting
				value: lightSliders[i].dimLevel,
				step: lightSliders[i].stepSize,
				//slide: lightControlEvent
			});
			$( "#lightSlider" + (i+1) ).slider( "value", lightSliders[i].dimLevel);
			$( "#lightSlider" + (i+1) ).slider({ stop: function( event, ui ) {lightControlEvent(this.id);}});
		}
    });    

	$(function() {
        $( "#tempSlider" ).slider({ //#lightSlider refers to slider for controlling artificial lighting
            orientation: "vertical",
            range: "min",
            min: 0,
            max: 100, //note 1000 lux represents the total available from the artificial lighting
            value: 50,
			step: 5,
            //slide: lightControlEvent
        });
        $( "#templider" ).slider( "value", 50);
		$( "#tempSlider" ).slider({ stop: function( event, ui ) {tempControlEvent();}});
    });
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	// REDRAW CODE FOR ENERGY CONSUMPTION FEEDBACK - 4 ENERGY STATES WITH 4 VISUALIZATIONS OF LEAF IMAGE
	// note that the calculation of energy states and feedback is not complete yet.
	////////////////////////////////////////////////////////////////////////////////////////////////////
	function updateLeaf() {
			//elem = document.getElementById("leaf");
			var visStatus = (artificialLightInside <= 50) ? "visible" : "hidden";
			if($("#leaf").css("visibility") != visStatus)
				$("#leaf").css("visibility",visStatus);
			/*
			if(artificialLightInside > 0 )
			{
				if(artificialLightInside > 50 && artificialLightInside < 200 && dayLightOutside > minLight)
					elem.src = "images/leaf1.png";
				else if(artificialLightInside > 199 && artificialLightInside < 400 && dayLightOutside > minLight)	
					elem.src = "images/leaf2.png";
				else if(artificialLightInside > 300 && dayLightOutside > minLight)
					elem.src = "images/leaf3.png";
				else  elem.src = "images/leaf0.png";
			}
			else elem.src = "images/leaf0.png"; */
	}


	////////////////////////////////////////////////////////////////////////////////////////////////////
	// CODE TO UPDATE AND REDRAW ALL SLIDERS
	////////////////////////////////////////////////////////////////////////////////////////////////////
	function redrawSliders() {
			$( "#lightSlider1" ).slider("value", artificialLightInside);
			updateLeaf();
	}
});